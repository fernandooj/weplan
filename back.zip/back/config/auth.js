module.exports = {

    'facebookAuth' : {
        'clientID'      : '412591535863567', // your App ID
        'clientSecret'  : 'a6743cd0ed5fb4e66e138aeebc43c4ce', // your App Secret
        'callbackURL'   : '/x/v1/auth/facebook/callback'
    },

    'googleAuth' : {
        'clientID'      : '986592850899-ha783khufam6ta5oad6hamb9lqpf3280.apps.googleusercontent.com',
        'clientSecret'  : '6zPmAljO_3H6GgAePok2Kl-v',
        'callbackURL'   : '/x/v1/auth/google/callback'
    }

};
