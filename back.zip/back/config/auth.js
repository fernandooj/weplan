module.exports = {

    'facebookAuth' : {
        'clientID'      : '1408822502487732', // your App ID
        'clientSecret'  : 'ca439bfe313eb9e6bb3b18f3c89a8816', // your App Secret
        'callbackURL'   : '/x/v1/auth/facebook/callback'
    },

    'googleAuth' : {
        'clientID'      : '241626662387-tbob7f8rfmgeo0gh3fd4dj1a1sfas70e.apps.googleusercontent.com',
        'clientSecret'  : 'fieFVrqLwvzcvuR-bf4wJ0r-',
        'callbackURL'   : '/x/v1/auth/google/callback'
    }

};
