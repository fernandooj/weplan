module.exports={
	'database': 'mongodb://localhost/weplan'
}